// options.js — handle saving and restoring the custom URL
document.addEventListener('DOMContentLoaded', () => {
  const ext = typeof browser !== 'undefined' ? browser : chrome;
  const input = document.getElementById('customUrl');
  const saveBtn = document.getElementById('save');
  const clearBtn = document.getElementById('clear');
  const statusEl = document.getElementById('status');

  let statusTimer = null;
  function showStatus(msg, isSuccess = true) {
    if (statusTimer) clearTimeout(statusTimer);
    statusEl.textContent = msg;
    statusEl.className = isSuccess ? 'success' : 'error';
    statusTimer = setTimeout(() => {
      statusEl.textContent = '';
      statusEl.className = '';
    }, 2500);
  }

  // Restore saved value
  try {
    const cached = localStorage.getItem('customUrl');
    if (cached) input.value = cached;
  } catch (e) {}

  if (ext && ext.storage && ext.storage.sync) {
    const getCb = (res) => {
      if (res && res.customUrl) {
        input.value = res.customUrl;
        try { localStorage.setItem('customUrl', res.customUrl); } catch (e) {}
      }
    };
    try {
      const p = ext.storage.sync.get(['customUrl']);
      if (p && typeof p.then === 'function') {
        p.then(getCb).catch(() => {});
      } else {
        ext.storage.sync.get(['customUrl'], getCb);
      }
    } catch (e) {}
  }

  function saveValue(val) {
    const trimmed = val.trim();
    if (trimmed.length > 2000) {
      showStatus('网址过长', false);
      return;
    }
    if (/^javascript:/i.test(trimmed)) {
      showStatus('不支持的协议', false);
      return;
    }

    if (!trimmed) {
      try { localStorage.removeItem('customUrl'); } catch (e) {}
      if (ext && ext.storage && ext.storage.sync) {
        const removeCb = () => showStatus('已清除');
        const p = ext.storage.sync.remove(['customUrl']);
        if (p && typeof p.then === 'function') p.then(removeCb).catch(removeCb);
        else ext.storage.sync.remove(['customUrl'], removeCb);
      } else {
        showStatus('已清除');
      }
      return;
    }

    try { localStorage.setItem('customUrl', trimmed); } catch (e) {}
    if (ext && ext.storage && ext.storage.sync) {
      const setCb = () => showStatus('已保存');
      const p = ext.storage.sync.set({ customUrl: trimmed });
      if (p && typeof p.then === 'function') p.then(setCb).catch(setCb);
      else ext.storage.sync.set({ customUrl: trimmed }, setCb);
    } else {
      showStatus('已保存');
    }
  }

  saveBtn.addEventListener('click', () => saveValue(input.value));
  clearBtn.addEventListener('click', () => {
    input.value = '';
    saveValue('');
  });
});
