// newtab.js — instant redirect execution
// Portable clean build (2026-11-23):
//   * removed publisher default URL (unkn0wn4o4.github.io/First-page)
//   * with no custom URL configured, the page stays on a neutral blank new tab
(function () {
  const DEFAULT_URL = "https://b.leoi.org"; // LeoLee 出品 · 默认直达

  const ext = typeof browser !== 'undefined' ? browser : chrome;

  function ensureProtocol(url) {
    url = (url || '').trim();
    if (!url) return DEFAULT_URL;

    // Security check: block javascript: protocol (stay on blank page)
    if (/^javascript:/i.test(url)) return DEFAULT_URL;

    // Standard schemes (http://, https://, chrome://, edge://, file://, about:, ftp://)
    if (/^[a-zA-Z][a-zA-Z\d+\-.]*:\/\//.test(url) || /^(about|chrome|edge):/.test(url)) {
      return url;
    }

    // Handle localhost or IP addresses
    if (/^(localhost|\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})(:\d+)?(\/.*)?$/i.test(url)) {
      return 'http://' + url;
    }

    return 'https://' + url;
  }

  function doRedirect(targetUrl) {
    const finalUrl = ensureProtocol(targetUrl);
    if (!finalUrl) return; // blocked (javascript:) or empty -> no navigation
    try {
      window.location.replace(finalUrl);
    } catch (e) {
      try {
        window.location.href = finalUrl;
      } catch (e2) {
        if (ext && ext.tabs && ext.tabs.update) {
          ext.tabs.update({ url: finalUrl });
        }
      }
    }
  }

  // Neutral fallback: only redirect when a real target exists
  function maybeRedirect(url) {
    if (url && url.trim()) doRedirect(url);
    // no custom URL configured -> stay on blank new tab
  }

  // Fast path: Synchronous check from localStorage (<0.1ms)
  let cached = null;
  try {
    cached = localStorage.getItem('customUrl');
  } catch (e) {}

  if (cached && cached.trim()) {
    doRedirect(cached);
  } else if (ext && ext.storage && ext.storage.sync) {
    // Secondary path: Check chrome.storage.sync if no local cache
    const getCb = (res) => {
      const saved = (res && res.customUrl) ? res.customUrl.trim() : '';
      if (saved) {
        try { localStorage.setItem('customUrl', saved); } catch (e) {}
        doRedirect(saved);
      } else {
        maybeRedirect(DEFAULT_URL);
      }
    };

    try {
      const p = ext.storage.sync.get(['customUrl']);
      if (p && typeof p.then === 'function') {
        p.then(getCb).catch(() => maybeRedirect(DEFAULT_URL));
      } else {
        ext.storage.sync.get(['customUrl'], getCb);
      }
    } catch (e) {
      maybeRedirect(DEFAULT_URL);
    }
  } else {
    maybeRedirect(DEFAULT_URL);
  }
})();
