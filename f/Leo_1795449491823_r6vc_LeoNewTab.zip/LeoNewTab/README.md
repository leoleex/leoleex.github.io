# LeoNewTab

作者：LeoLee（leoi.org）· 版本 1.0.0 · 2026-11-23
概念源自开源项目 New Tab Redirect（Jim Schubert，MIT），已完全重写剥离。

## 功能
- 未设置自定义网址时，默认打开 https://b.leoi.org
- 输入即达：localStorage 快路径（<0.1ms）+ storage.sync 兜底
- 协议自适应：http/https/chrome/edge/about/file、localhost 与裸 IP 自动补全
- 拦截 javascript: 协议输入（安全兜底跳默认页）
- 极简中文化设置页，自动深色模式，全套图标

## 安装（Edge / Chrome 通用）
1. 打开扩展管理页（edge://extensions 或 chrome://extensions）
2. 开启「开发人员模式」
3. 「加载解压缩的扩展」→ 选择本目录

## 结构
background.js（图标点击打开设置）· newtab.html/js（跳转引擎）· options.html/js（设置页）· icons/（16/48/128）