// background.js — lightweight service worker for extension icon click
const ext = typeof browser !== 'undefined' ? browser : chrome;

if (ext && ext.action && ext.action.onClicked) {
  ext.action.onClicked.addListener(() => {
    if (ext.runtime && ext.runtime.openOptionsPage) {
      ext.runtime.openOptionsPage();
    }
  });
}
